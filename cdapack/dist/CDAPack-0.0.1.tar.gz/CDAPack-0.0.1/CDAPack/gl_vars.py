# gl_vars.py
from typing import *


data = dict()

root = None

nb = None

pages = dict()

chk_var_list1 = dict()

chk_var_list2 = dict()

chk_var_list3 = dict()

spn_box_list = dict()

output = None

selBox = None
opBox = None

