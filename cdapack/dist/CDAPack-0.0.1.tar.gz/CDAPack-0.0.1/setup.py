import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="CDAPack",
    version="0.0.1",
    author="Aditya Vasudevan",
    author_email="aditya2499@gmail.com",
    description="A Climate Data Analysis package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/adivas24/NCPOR",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)