#init.py
temp = "Hallelujha"